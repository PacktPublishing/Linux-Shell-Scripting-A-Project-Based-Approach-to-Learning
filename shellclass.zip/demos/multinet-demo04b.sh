#!/bin/bash
PATH="${PATH}:/usr/sbin:/sbin"
echo "${PATH}"
